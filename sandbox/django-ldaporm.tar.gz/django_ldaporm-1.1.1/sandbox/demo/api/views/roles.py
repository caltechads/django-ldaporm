from typing import TYPE_CHECKING, ClassVar, cast

from rest_framework import viewsets
from rest_framework.filters import BaseFilterBackend, SearchFilter
from rest_framework.response import Response

from demo.core.ldap.models import NSRole
from ldaporm.restframework import LdapCursorPagination, LdapOrderingFilter

from ..serializers import NSRoleSerializer

if TYPE_CHECKING:
    from ldaporm.managers import LdapManager


class NSRoleViewSet(viewsets.ModelViewSet):
    """
    ViewSet for NSRole operations.
    Provides CRUD operations for NSRoles with filtering and ordering support.
    """

    serializer_class = NSRoleSerializer
    model = NSRole
    pagination_class = LdapCursorPagination  # Requires real LDAP server for testing
    filter_backends: ClassVar[list[BaseFilterBackend]] = [
        SearchFilter,
        LdapOrderingFilter,  # Requires real LDAP server for testing
    ]

    # Define which fields can be used for searching
    search_fields = (
        "cn",
        "description",
    )

    # Define which fields can be used for ordering
    ordering_fields = (
        "cn",
        "description",
    )

    ordering = ("cn",)

    def get_queryset(self):
        """
        Return the NSRole queryset.
        """
        return cast("LdapManager", NSRole.objects).all()
