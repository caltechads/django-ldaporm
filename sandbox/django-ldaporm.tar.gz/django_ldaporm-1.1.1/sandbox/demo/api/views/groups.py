from typing import TYPE_CHECKING, ClassVar, cast

from rest_framework import viewsets
from rest_framework.filters import BaseFilterBackend, SearchFilter
from rest_framework.response import Response

from demo.core.ldap.models import LDAPGroup
from ldaporm.restframework import LdapCursorPagination, LdapOrderingFilter

from ..serializers import LDAPGroupSerializer

if TYPE_CHECKING:
    from ldaporm.managers import LdapManager


class LDAPGroupViewSet(viewsets.ModelViewSet):
    """
    ViewSet for LDAP Group operations.
    Provides CRUD operations for LDAP groups with filtering and ordering support.
    """

    serializer_class = LDAPGroupSerializer
    model = LDAPGroup
    pagination_class = LdapCursorPagination  # Requires real LDAP server for testing
    filter_backends: ClassVar[list[BaseFilterBackend]] = [
        SearchFilter,
        LdapOrderingFilter,  # Requires real LDAP server for testing
    ]

    # Define which fields can be used for searching
    search_fields = (
        "cn",
        "gid_number",
        "description",
        "member_uids",
    )

    # Define which fields can be used for ordering
    ordering_fields = (
        "cn",
        "gid_number",
        "description",
        "member_uids",
    )

    ordering = ("cn",)

    def get_queryset(self):
        """
        Return the LDAP group queryset.
        """
        return cast("LdapManager", LDAPGroup.objects).all()
