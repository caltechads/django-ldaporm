from typing import TYPE_CHECKING, ClassVar, cast

from rest_framework import viewsets
from rest_framework.filters import BaseFilterBackend, SearchFilter
from rest_framework.response import Response

from demo.core.ldap.models import LDAPUser
from ldaporm.restframework import LdapCursorPagination, LdapOrderingFilter

from ..serializers import LDAPUserSerializer

if TYPE_CHECKING:
    from ldaporm.managers import LdapManager


class LDAPUserViewSet(viewsets.ModelViewSet):
    """
    ViewSet for LDAP User operations.
    Provides CRUD operations for LDAP users with filtering and ordering support.

    This ViewSet demonstrates how to use LdapOrderingFilter alongside other
    filter backends like SearchFilter. The ordering filter leverages LDAP ORM's
    server-side sorting capabilities when available.

    Example API calls:
    - GET /api/users/                           # Default ordering (uid)
    - GET /api/users/?ordering=cn               # Order by cn ascending
    - GET /api/users/?ordering=-cn              # Order by cn descending
    - GET /api/users/?ordering=uid,-cn,mail     # Multiple field ordering
    - GET /api/users/?search=john&ordering=cn   # Search + ordering
    """

    serializer_class = LDAPUserSerializer
    model = LDAPUser
    pagination_class = LdapCursorPagination  # Requires real LDAP server for testing
    filter_backends: ClassVar[list[BaseFilterBackend]] = [
        SearchFilter,
        LdapOrderingFilter,  # Requires real LDAP server for testing
    ]

    # Define which fields can be used for searching
    search_fields = (
        "uid",
        "cn",
        "mail",
        "employee_number",
        "employee_type",
        "full_name",
        "gid_number",
        "uid_number",
        "login_shell",
        "home_directory",
        "home_phone",
        "mobile",
        "nsroledn",
    )

    # Define which fields can be used for ordering
    ordering_fields = (
        "uid",
        "cn",
        "mail",
        "employee_number",
        "employee_type",
        "full_name",
        "gid_number",
        "uid_number",
        "login_shell",
        "home_directory",
        "home_phone",
        "mobile",
    )

    ordering = ("uid",)

    def get_queryset(self):
        """
        Return the LDAP user queryset.
        """
        return cast("LdapManager", LDAPUser.objects).all()
