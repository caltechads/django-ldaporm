from .settings import *  # noqa: F403


DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.sqlite3",
        "NAME": "testdb",
    }
}

LDAP_SERVERS = {
    "default": {
        "basedn": "o=example,c=us",  # type: ignore[arg-type, assignment]
        "read": {
            "url": "ldap://ldap:389",  # type: ignore[arg-type, assignment]
            "user": "uid=binduser,ou=people,dc=example,dc=com",
            "password": "password123",
        },
        "write": {
            "url": "ldap://ldap:389",  # type: ignore[arg-type, assignment]
            "user": "uid=binduser,ou=people,dc=example,dc=com",
            "password": "password123",
        },
    }
}
