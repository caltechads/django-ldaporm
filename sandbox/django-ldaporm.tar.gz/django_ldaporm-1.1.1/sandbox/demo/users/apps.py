from django.apps import AppConfig


class UsersConfig(AppConfig):
    name: str = "demo.users"
    label: str = "users"
