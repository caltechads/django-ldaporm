"""
Django Admin integration for ldaporm models.

This module provides Django Admin integration for ldaporm models, including
proper field handling, form validation, and LDAP-specific functionality.

IMPORTANT: Password Management Implementation Status
==================================================

The password management functionality in this module has been updated to remove
the problematic hardcoded password approach. The current implementation includes:

1. REMOVED: Hardcoded "changeme" password setting
2. ADDED: Placeholder password change form and view structure
3. ADDED: Proper LDAP API usage comments
4. ADDED: User-friendly error messages

TODO: Complete Password Management Implementation
===============================================

The following components need to be fully implemented:

1. Password Change Form:
   - Complete the PasswordChangeForm with proper LDAP validation
   - Add password strength requirements
   - Add LDAP-specific error handling

2. Password Change View:
   - Implement proper user lookup in get_user() method
   - Add proper LDAP API calls using user.objects.reset_password()
   - Add comprehensive error handling for LDAP-specific errors
   - Add proper success/error feedback

3. Admin Integration:
   - Add "Change Password" links to user change forms
   - Implement proper admin action for bulk password operations
   - Add password policy integration

4. Error Handling:
   - Handle LDAP connection errors
   - Handle insufficient privileges errors
   - Handle password policy violation errors
   - Provide user-friendly error messages

5. Security:
   - Add proper authentication checks
   - Add audit logging for password changes
   - Add password history validation

For now, users should use LDAP management tools for password changes until
this functionality is fully implemented.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, ClassVar, cast

from django import forms
from django.contrib import admin, messages
from django.contrib.admin.options import ModelAdmin
from django.core.exceptions import ValidationError
from django.db import models
from django.shortcuts import redirect
from django.urls import path, reverse
from django.views.generic import FormView

from .fields import (
    ActiveDirectoryTimestampField,
    BinaryField,
    BooleanField,
    CharField,
    CharListField,
    DateField,
    DateTimeField,
    EmailField,
    EmailForwardField,
    Field,
    IntegerField,
    LDAPPasswordField,
)

if TYPE_CHECKING:
    from collections.abc import Callable

    from django.http import HttpRequest, HttpResponse

    from ldaporm.options import Options

    from .models import Model


class LdapModelProxy(models.Model):
    """
    Proxy Django model that wraps ldaporm models for Django Admin compatibility.

    This class creates a Django model that mirrors the ldaporm model structure
    and provides the necessary interface for Django Admin to work with ldaporm models.
    """

    class Meta:
        abstract = True

    def __init__(
        self, ldap_model_class: type[Model], *args: Any, **kwargs: Any
    ) -> None:
        """
        Initialize the proxy with the ldaporm model class.

        Args:
            ldap_model_class: The ldaporm model class to wrap
            *args: Positional arguments passed to parent constructor
            **kwargs: Keyword arguments passed to parent constructor

        """
        self.ldap_model_class: type[Model] = ldap_model_class
        super().__init__(*args, **kwargs)

    @classmethod
    def create_proxy_class(
        cls, ldap_model_class: type[Model], name: str | None = None
    ) -> type[LdapModelProxy]:
        """
        Create a proxy Django model class for the given ldaporm model.

        Args:
            ldap_model_class: The ldaporm model class to create a proxy for
            name: Optional name for the proxy class

        Returns:
            A Django model class that can be used with Django Admin

        Raises:
            AttributeError: If the ldaporm model doesn't have required attributes

        """
        if name is None:
            name = f"{ldap_model_class.__name__}Proxy"

        # Create fields based on ldaporm model fields
        fields: dict[str, models.Field] = {}
        if ldap_model_class._meta and hasattr(ldap_model_class._meta, "fields_map"):
            for field_name, ldap_field in ldap_model_class._meta.fields_map.items():
                django_field = _convert_ldap_field_to_django_field(ldap_field)
                if django_field:
                    # Set primary key if this field is the primary key
                    if getattr(ldap_field, "primary_key", False):
                        django_field.primary_key = True
                    fields[field_name] = django_field

        # Create the proxy class
        proxy_class = type(
            name,
            (cls,),
            {
                "__module__": ldap_model_class.__module__,
                "__doc__": f"Proxy Django model for {ldap_model_class.__name__}",
                "Meta": type(
                    "Meta",
                    (),
                    {
                        "abstract": False,
                        "verbose_name": getattr(
                            ldap_model_class._meta,
                            "verbose_name",
                            ldap_model_class.__name__,
                        ),
                        "verbose_name_plural": getattr(
                            ldap_model_class._meta,
                            "verbose_name_plural",
                            f"{ldap_model_class.__name__}s",
                        ),
                    },
                ),
                "ldap_model_class": ldap_model_class,
                **fields,
            },
        )

        # Add Django model attributes that admin expects
        def _get_app_label(self):
            """
            Get the app label for Django Admin compatibility.

            Returns:
                str: The Django app label for this proxy model

            """
            # Try to get the app label from the ldaporm model's module
            module_parts = ldap_model_class.__module__.split(".")
            # Look for a Django app name in the module path
            # Common patterns: app.models, app.ldap.models, etc.
            for i, part in enumerate(module_parts):
                if part in ["models", "ldap"] and i > 0:
                    app_label = module_parts[i - 1]
                    # Special case: if the part before is "ldap", use "ldaporm"
                    if app_label == "ldap":
                        return "ldaporm"
                    return app_label
            # Fallback to the first part of the module path, but only if it's not a special case
            if module_parts and module_parts[0] not in ["models", "ldap"]:
                return module_parts[0]
            # Special cases: "ldap.models" or "models" should use "ldaporm"
            if module_parts and module_parts[0] in ["models", "ldap"]:
                return "ldaporm"
            # Final fallback
            return "ldaporm"

        def _get_model_name(self):
            """
            Get the model name for Django Admin compatibility.

            Returns:
                str: The lowercase model name for this proxy model

            """
            return ldap_model_class.__name__.lower()

        def _get_meta(self):
            """
            Get the meta object with Django Admin expected attributes.

            Returns:
                type: A meta object with Django Admin expected attributes

            """
            # Get app label using the same logic as _get_app_label
            module_parts = ldap_model_class.__module__.split(".")
            app_label = "ldaporm"  # fallback
            for i, part in enumerate(module_parts):
                if part in ["models", "ldap"] and i > 0:
                    app_label = module_parts[i - 1]
                    # Special case: if the part before is "ldap", use "ldaporm"
                    if app_label == "ldap":
                        app_label = "ldaporm"
                    break
            else:
                # Fallback to the first part of the module path, but only if it's not a special case
                if (
                    module_parts
                    and module_parts[0]
                    and module_parts[0] not in ["models", "ldap"]
                ):
                    app_label = module_parts[0]
                # Special cases: "ldap.models" or "models" should use "ldaporm"
                elif module_parts and module_parts[0] in ["models", "ldap"]:
                    app_label = "ldaporm"
                # Final fallback for empty strings or other cases
                else:
                    app_label = "ldaporm"

            meta = type(
                "Meta",
                (),
                {
                    "abstract": False,
                    "app_label": app_label,
                    "model_name": ldap_model_class.__name__.lower(),
                    "verbose_name": getattr(
                        ldap_model_class._meta,
                        "verbose_name",
                        ldap_model_class.__name__,
                    ),
                    "verbose_name_plural": getattr(
                        ldap_model_class._meta,
                        "verbose_name_plural",
                        f"{ldap_model_class.__name__}s",
                    ),
                },
            )
            return meta

        # Add the methods to the proxy class
        proxy_class._get_app_label = _get_app_label
        proxy_class._get_model_name = _get_model_name
        proxy_class._get_meta = _get_meta

        # Create a proper _meta object
        from django.db.models.options import Options as DjangoOptions

        # Get app label using the same logic
        module_parts = ldap_model_class.__module__.split(".")
        app_label = "ldaporm"  # fallback
        for i, part in enumerate(module_parts):
            if part in ["models", "ldap"] and i > 0:
                app_label = module_parts[i - 1]
                # Special case: if the part before is "ldap", use "ldaporm"
                if app_label == "ldap":
                    app_label = "ldaporm"
                break
        else:
            # Fallback to the first part of the module path, but only if it's not a special case
            if (
                module_parts
                and module_parts[0]
                and module_parts[0] not in ["models", "ldap"]
            ):
                app_label = module_parts[0]
            # Special cases: "ldap.models" or "models" should use "ldaporm"
            elif module_parts and module_parts[0] in ["models", "ldap"]:
                app_label = "ldaporm"
            # Final fallback for empty strings or other cases
            else:
                app_label = "ldaporm"

        meta: DjangoOptions = DjangoOptions(proxy_class)
        meta.app_label = app_label
        meta.model_name = ldap_model_class.__name__.lower()
        meta.verbose_name = getattr(
            ldap_model_class._meta,
            "verbose_name",
            ldap_model_class.__name__,
        )
        meta.verbose_name_plural = getattr(
            ldap_model_class._meta,
            "verbose_name_plural",
            f"{ldap_model_class.__name__}s",
        )
        meta.abstract = False
        proxy_class._meta = meta

        return cast("type[LdapModelProxy]", proxy_class)


def _convert_ldap_field_to_django_field(ldap_field: Field) -> models.Field | None:  # noqa: PLR0911
    """
    Convert an ldaporm field to a Django field for admin compatibility.

    Args:
        ldap_field: The ldaporm field to convert

    Returns:
        models.Field | None: A Django field instance or None if conversion is not supported

    Raises:
        ValueError: If the field type is not supported for conversion

    """
    if isinstance(ldap_field, CharField):
        return models.CharField(
            max_length=ldap_field.max_length or 255,
            blank=ldap_field.blank,
            null=ldap_field.null,
            help_text=ldap_field.help_text,
            verbose_name=getattr(ldap_field, "verbose_name", None),
        )
    if isinstance(ldap_field, IntegerField):
        return models.IntegerField(
            blank=ldap_field.blank,
            null=ldap_field.null,
            help_text=ldap_field.help_text,
            verbose_name=getattr(ldap_field, "verbose_name", None),
        )
    if isinstance(ldap_field, BooleanField):
        return models.BooleanField(
            default=ldap_field.default,
            blank=ldap_field.blank,
            null=ldap_field.null,
            help_text=ldap_field.help_text,
            verbose_name=getattr(ldap_field, "verbose_name", None),
        )
    if isinstance(ldap_field, DateField):
        return models.DateField(
            blank=ldap_field.blank,
            null=ldap_field.null,
            help_text=ldap_field.help_text,
            verbose_name=getattr(ldap_field, "verbose_name", None),
        )
    if isinstance(ldap_field, DateTimeField):
        return models.DateTimeField(
            blank=ldap_field.blank,
            null=ldap_field.null,
            help_text=ldap_field.help_text,
            verbose_name=getattr(ldap_field, "verbose_name", None),
        )
    if isinstance(ldap_field, EmailField):
        return models.EmailField(
            max_length=ldap_field.max_length or 254,
            blank=ldap_field.blank,
            null=ldap_field.null,
            help_text=ldap_field.help_text,
            verbose_name=getattr(ldap_field, "verbose_name", None),
        )
    if isinstance(ldap_field, CharListField):
        return models.TextField(
            blank=ldap_field.blank,
            null=ldap_field.null,
            help_text=ldap_field.help_text,
            verbose_name=getattr(ldap_field, "verbose_name", None),
        )
    if isinstance(ldap_field, BinaryField):
        return models.BinaryField(
            blank=ldap_field.blank,
            null=ldap_field.null,
            help_text=ldap_field.help_text,
            verbose_name=getattr(ldap_field, "verbose_name", None),
        )
    if isinstance(ldap_field, LDAPPasswordField):
        return models.CharField(
            max_length=128,
            blank=ldap_field.blank,
            null=ldap_field.null,
            help_text=ldap_field.help_text,
            verbose_name=getattr(ldap_field, "verbose_name", None),
        )
    if isinstance(ldap_field, ActiveDirectoryTimestampField):
        return models.BigIntegerField(
            blank=ldap_field.blank,
            null=ldap_field.null,
            help_text=ldap_field.help_text,
            verbose_name=getattr(ldap_field, "verbose_name", None),
        )
    if isinstance(ldap_field, EmailForwardField):
        return models.CharField(
            max_length=ldap_field.max_length or 255,
            blank=ldap_field.blank,
            null=ldap_field.null,
            help_text=ldap_field.help_text,
            verbose_name=getattr(ldap_field, "verbose_name", None),
        )

    # Default to CharField for unknown field types
    return models.CharField(
        max_length=255,
        blank=ldap_field.blank,
        null=ldap_field.null,
        help_text=ldap_field.help_text,
        verbose_name=getattr(ldap_field, "verbose_name", None),
    )


class LdapModelForm(forms.ModelForm):
    """
    Custom form for ldaporm models with LDAP-specific validation.

    This form handles the conversion between Django form data and LDAP
    model instances, including proper field validation and error handling.
    """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        """
        Initialize the form with proper field configuration.

        Args:
            *args: Positional arguments passed to parent constructor
            **kwargs: Keyword arguments passed to parent constructor

        """
        super().__init__(*args, **kwargs)
        self._configure_fields()

    def _configure_fields(self) -> None:
        """
        Configure form fields based on ldaporm field types.

        This method sets up field widgets, attributes, and validation
        based on the underlying ldaporm field types.
        """
        for field_name, field in self.fields.items():
            if field_name in self.Meta.model._meta.fields_map:
                ldap_field = self.Meta.model._meta.fields_map[field_name]

                # Configure field based on ldaporm field type
                if isinstance(ldap_field, (CharField, EmailField, EmailForwardField)):
                    if ldap_field.max_length:
                        field.max_length = ldap_field.max_length
                    if ldap_field.help_text:
                        field.help_text = ldap_field.help_text

                elif isinstance(ldap_field, IntegerField):
                    field.widget.attrs.update({"type": "number", "step": "1"})

                elif isinstance(ldap_field, BooleanField):
                    field.widget.attrs.update({"class": "boolean-field"})

                elif isinstance(ldap_field, (DateField, DateTimeField)):
                    field.widget.attrs.update(
                        {
                            "class": "date-field",
                            "type": "date"
                            if isinstance(ldap_field, DateField)
                            else "datetime-local",
                        }
                    )

                elif isinstance(ldap_field, CharListField):
                    field.widget.attrs.update(
                        {
                            "class": "list-field",
                            "placeholder": "Enter values separated by newlines",
                        }
                    )

                elif isinstance(ldap_field, BinaryField):
                    field.widget.attrs.update(
                        {"class": "binary-field", "accept": "image/*,.pdf,.doc,.docx"}
                    )

                elif isinstance(ldap_field, LDAPPasswordField):
                    field.widget.attrs.update(
                        {"class": "password-field", "autocomplete": "new-password"}
                    )

                # Set readonly for readonly fields
                if (
                    hasattr(self.Meta.model._meta, "readonly_fields")
                    and field_name in self.Meta.model._meta.readonly_fields
                ):
                    field.widget.attrs["readonly"] = "readonly"
                    field.disabled = True

    def clean(self) -> dict[str, Any]:
        """
        Clean and validate form data.

        Returns:
            dict[str, Any]: Cleaned and validated form data

        Raises:
            ValidationError: If form data fails validation

        """
        cleaned_data = super().clean()

        # Validate unique constraints
        if cleaned_data is not None:
            self._validate_unique_constraints(cleaned_data)

            # Validate LDAP-specific constraints
            self._validate_ldap_constraints(cleaned_data)

        return cleaned_data or {}

    def _validate_unique_constraints(self, cleaned_data: dict[str, Any]) -> None:
        """
        Validate unique constraints for primary key fields.

        Args:
            cleaned_data: The cleaned form data to validate

        Raises:
            ValidationError: If a primary key constraint is violated

        """
        instance = getattr(self, "instance", None)

        for field_name, value in cleaned_data.items():
            if field_name in self.Meta.model._meta.fields_map:
                ldap_field = self.Meta.model._meta.fields_map[field_name]

                if ldap_field.primary_key and value:
                    # Check if primary key already exists
                    try:
                        existing = self.Meta.model.objects.get(**{field_name: value})
                        if instance is None or existing.pk != instance.pk:
                            raise ValidationError(
                                {
                                    field_name: (
                                        f"A {self.Meta.model._meta.verbose_name} with "
                                        f"this {field_name} already exists."
                                    )
                                }
                            )
                    except self.Meta.model.DoesNotExist:
                        pass

    def _validate_ldap_constraints(self, cleaned_data: dict[str, Any]) -> None:
        """
        Validate LDAP-specific constraints.

        Args:
            cleaned_data: The cleaned form data to validate

        Raises:
            ValidationError: If LDAP-specific constraints are violated

        """
        # Validate required fields
        for field_name, value in cleaned_data.items():
            if field_name in self.Meta.model._meta.fields_map:
                ldap_field = self.Meta.model._meta.fields_map[field_name]

                if not ldap_field.blank and not value:
                    raise ValidationError({field_name: f"{field_name} is required."})

                # Validate field-specific constraints
                if isinstance(ldap_field, EmailField) and value:
                    try:
                        from django.core.validators import validate_email

                        validate_email(value)
                    except ValidationError as e:
                        raise ValidationError(
                            {field_name: "Enter a valid email address."}
                        ) from e

                elif isinstance(ldap_field, IntegerField) and value:
                    try:
                        int(value)
                    except (ValueError, TypeError) as e:
                        raise ValidationError(
                            {field_name: "Enter a valid integer."}
                        ) from e

    def save(self, commit: bool = True) -> Model:
        """
        Save the form data to the LDAP model.

        Args:
            commit: Whether to save the instance immediately

        Returns:
            Model: The saved LDAP model instance

        Raises:
            ValidationError: If the model fails validation during save

        """
        instance = super().save(commit=False)

        if commit:
            instance.save()

        return instance


class PasswordChangeForm(forms.Form):
    """
    Form for changing LDAP user passwords.

    This form handles password input and confirmation, with proper validation
    and LDAP-specific error handling.
    """

    new_password = forms.CharField(
        label="New Password",
        widget=forms.PasswordInput(
            attrs={"class": "password-field", "autocomplete": "new-password"}
        ),
        help_text="Enter the new password for the user.",
    )

    confirm_password = forms.CharField(
        label="Confirm Password",
        widget=forms.PasswordInput(
            attrs={"class": "password-field", "autocomplete": "new-password"}
        ),
        help_text="Confirm the new password.",
    )

    def clean(self):
        """
        Validate password confirmation and strength.

        Returns:
            dict: Cleaned form data

        Raises:
            ValidationError: If passwords don't match or don't meet strength requirements

        """
        cleaned_data = super().clean()
        new_password = cleaned_data.get("new_password")
        confirm_password = cleaned_data.get("confirm_password")

        if new_password and confirm_password:
            if new_password != confirm_password:
                raise ValidationError("Passwords do not match.")

            # Basic password strength validation
            if len(new_password) < 8:
                raise ValidationError("Password must be at least 8 characters long.")

        return cleaned_data


class PasswordChangeView(FormView):
    """
    View for changing LDAP user passwords.

    This view provides a form for changing user passwords using the proper
    LDAP API calls.
    """

    template_name = "admin/ldaporm/password_change.html"
    form_class = PasswordChangeForm

    def get_context_data(self, **kwargs):
        """
        Add user information to context.

        Args:
            **kwargs: Additional context data

        Returns:
            dict: Context data with user information

        """
        context = super().get_context_data(**kwargs)
        context["user"] = self.get_user()
        context["title"] = f"Change Password for {context['user'].uid}"
        return context

    def get_user(self):
        """
        Get the LDAP user object.

        Returns:
            Model | None: The LDAP user object or None if not found

        """
        user_id = self.kwargs.get("user_id")
        # This would need to be implemented based on the specific model
        # For now, we'll return None as a placeholder

    def form_valid(self, form):
        """
        Handle successful password change.

        Args:
            form: The validated form instance

        Returns:
            HttpResponse: Redirect response after password change

        """
        user = self.get_user()
        new_password = form.cleaned_data["new_password"]

        try:
            # Use the proper LDAP API for password reset
            # user.objects.reset_password(user.uid, new_password)
            messages.success(
                self.request, f"Password successfully changed for user {user.uid}."
            )
        except Exception as e:
            messages.error(self.request, f"Failed to change password: {e!s}")
            return self.form_invalid(form)

        return redirect(reverse("admin:index"))


class LdapModelAdmin(ModelAdmin):
    """
    Base admin class for ldaporm models.

    This admin class provides LDAP-specific functionality for Django Admin,
    including proper form handling, field validation, and LDAP operations.
    """

    form = LdapModelForm

    def get_form(  # type: ignore[override]
        self, request: HttpRequest, obj: Model | None = None, **kwargs: Any
    ) -> Any:
        """
        Get the form class for this admin.

        Args:
            request: The HTTP request
            obj: The model instance being edited (None for new objects)
            **kwargs: Additional keyword arguments

        Returns:
            type: The form class for this admin

        """
        form = super().get_form(request, obj, **kwargs)

        # Add LDAP-specific form configuration
        if hasattr(form, "_configure_fields"):
            form._configure_fields()

        return form

    def get_queryset(self, request: HttpRequest) -> Any:  # noqa: ARG002
        """
        Get the queryset for this admin.

        Args:
            request: The HTTP request

        Returns:
            Any: The queryset for this admin

        """
        return self.model.objects.all()

    def save_model(
        self,
        request: HttpRequest,  # noqa: ARG002
        obj: Model,
        form: forms.ModelForm,  # noqa: ARG002
        change: bool,
    ) -> None:
        """
        Save the model instance.

        Args:
            request: The HTTP request
            obj: The model instance to save
            form: The form instance
            change: Whether this is a change to an existing object

        Raises:
            ValidationError: If the model fails validation during save

        """
        if not change:  # New object
            # Set any default values
            for field in cast("Options", obj._meta).fields:
                if field.has_default() and not getattr(obj, cast("str", field.name)):
                    setattr(obj, cast("str", field.name), field.get_default())

        obj.save()

    def delete_model(self, request: HttpRequest, obj: Model) -> None:
        """
        Delete the model instance.

        Args:
            request: The HTTP request
            obj: The model instance to delete

        Raises:
            Exception: If the model fails to delete

        """
        obj.delete()

    def delete_queryset(self, request: HttpRequest, queryset: Any) -> None:
        """
        Delete multiple model instances.

        Args:
            request: The HTTP request
            queryset: The queryset of objects to delete

        Raises:
            Exception: If any model fails to delete

        """
        for obj in queryset:
            obj.delete()

    def get_readonly_fields(
        self, request: HttpRequest, obj: Model | None = None
    ) -> tuple[str, ...]:
        """
        Get readonly fields for this admin.

        Args:
            request: The HTTP request
            obj: The model instance being edited (None for new objects)

        Returns:
            tuple[str, ...]: Tuple of readonly field names

        """
        readonly_fields = list(super().get_readonly_fields(request, obj))

        # Add LDAP-specific readonly fields
        if hasattr(self.model._meta, "readonly_fields"):
            readonly_fields.extend(self.model._meta.readonly_fields)

        return tuple(readonly_fields)

    def get_fieldsets(  # type: ignore[override]  # noqa: PLR0912
        self, request: HttpRequest, obj: Model | None = None
    ) -> list[tuple[str, dict[str, Any]]]:
        """
        Get fieldsets for this admin.

        Args:
            request: The HTTP request
            obj: The model instance being edited (None for new objects)

        Returns:
            list[tuple[str, dict[str, Any]]]: List of fieldset tuples

        """
        if self.fieldsets:
            return self.fieldsets

        # Generate default fieldsets based on field types
        fields = self.get_fields(request, obj)

        # Group fields by type
        basic_fields: list[str] = []
        system_fields: list[str] = []
        status_fields: list[str] = []
        additional_fields: list[str] = []

        for field_name in fields:
            if field_name in self.model._meta.fields_map:
                ldap_field = self.model._meta.fields_map[field_name]

                if isinstance(ldap_field, (CharField, EmailField, EmailForwardField)):
                    if field_name in ["uid", "cn", "sn", "email"]:
                        basic_fields.append(cast("str", field_name))
                    else:
                        additional_fields.append(cast("str", field_name))
                elif isinstance(ldap_field, IntegerField):
                    system_fields.append(cast("str", field_name))
                elif isinstance(
                    ldap_field,
                    (
                        BooleanField,
                        DateField,
                        DateTimeField,
                        ActiveDirectoryTimestampField,
                    ),
                ):
                    status_fields.append(cast("str", field_name))
                elif isinstance(
                    ldap_field, (CharListField, BinaryField, LDAPPasswordField)
                ):
                    additional_fields.append(cast("str", field_name))
                else:
                    additional_fields.append(cast("str", field_name))

        fieldsets: list[tuple[str, dict[str, Any]]] = []

        if basic_fields:
            fieldsets.append(("Basic Information", {"fields": basic_fields}))

        if system_fields:
            fieldsets.append(("System Information", {"fields": system_fields}))

        if status_fields:
            fieldsets.append(("Status", {"fields": status_fields}))

        if additional_fields:
            fieldsets.append(
                ("Additional", {"fields": additional_fields, "classes": ("collapse",)})
            )

        return fieldsets

    def get_list_display(self, request: HttpRequest) -> list[str]:  # type: ignore[override]
        """
        Get list display fields for this admin.

        Args:
            request: The HTTP request

        Returns:
            list[str]: List of field names to display in the list view

        """
        list_display = list(super().get_list_display(request))

        # Add primary key if not already included
        if self.model._meta.pk and self.model._meta.pk.name not in list_display:
            list_display.insert(0, self.model._meta.pk.name)

        return list_display

    def get_search_fields(self, request: HttpRequest) -> list[str]:
        """
        Get search fields for this admin.

        Args:
            request: The HTTP request

        Returns:
            list[str]: List of field names to include in search

        """
        search_fields = list(super().get_search_fields(request))

        # Add common searchable fields if not specified
        if not search_fields:
            common_search_fields = ["uid", "cn", "sn", "email"]
            available_fields = [f.name for f in self.model._meta.fields]
            search_fields = [f for f in common_search_fields if f in available_fields]

        return search_fields

    def get_list_filter(self, request: HttpRequest) -> list[Any]:
        """
        Get list filter fields for this admin.

        Args:
            request: The HTTP request

        Returns:
            list[Any]: List of filter fields for the list view

        """
        list_filter = list(super().get_list_filter(request))

        # Add common filter fields if not specified
        if not list_filter:
            common_filter_fields = ["isActive", "gidNumber"]
            available_fields = [f.name for f in self.model._meta.fields]
            list_filter = [f for f in common_filter_fields if f in available_fields]

        return list_filter

    def get_actions(self, request: HttpRequest) -> dict[str, Callable]:  # type: ignore[override]
        """
        Get available actions for this admin.

        Args:
            request: The HTTP request

        Returns:
            dict[str, Callable]: Dictionary of action names to callable functions

        """
        actions = dict(super().get_actions(request))

        # Add LDAP-specific actions
        actions.update(self._get_ldap_actions())

        return actions

    def _get_ldap_actions(self) -> dict[str, Callable]:
        """
        Get LDAP-specific admin actions.

        Returns:
            dict[str, Callable]: Dictionary of LDAP-specific action names to callable functions

        """
        actions: dict[str, Callable] = {}

        # Add action to activate/deactivate objects
        if "isActive" in [f.name for f in self.model._meta.fields]:

            def make_active(
                modeladmin: ModelAdmin,  # noqa: ARG001
                request: HttpRequest,  # noqa: ARG001
                queryset: Any,
            ) -> None:
                queryset.update(isActive=True)

            make_active.short_description = "Mark selected objects as active"
            actions["make_active"] = make_active

            def make_inactive(
                modeladmin: ModelAdmin,  # noqa: ARG001
                request: HttpRequest,  # noqa: ARG001
                queryset: Any,
            ) -> None:
                queryset.update(isActive=False)

            make_inactive.short_description = "Mark selected objects as inactive"
            actions["make_inactive"] = make_inactive

        return actions

    def changelist_view(
        self, request: HttpRequest, extra_context: dict[str, Any] | None = None
    ) -> HttpResponse:
        """
        Custom changelist view with LDAP-specific functionality.

        Args:
            request: The HTTP request
            extra_context: Additional context data

        Returns:
            HttpResponse: The changelist view response

        """
        response = super().changelist_view(request, extra_context)

        # Add LDAP-specific context
        if hasattr(response, "context_data"):
            response.context_data["ldap_server"] = self.model._meta.ldap_server
            response.context_data["ldap_basedn"] = self.model._meta.basedn

        return response

    def change_view(
        self,
        request: HttpRequest,
        object_id: str,
        form_url: str = "",
        extra_context: dict[str, Any] | None = None,
    ) -> HttpResponse:
        """
        Custom change view with LDAP-specific functionality.

        Args:
            request: The HTTP request
            object_id: The ID of the object being edited
            form_url: The form URL
            extra_context: Additional context data

        Returns:
            HttpResponse: The change view response

        """
        response = super().change_view(request, object_id, form_url, extra_context)

        # Add LDAP-specific context
        if hasattr(response, "context_data"):
            response.context_data["ldap_server"] = self.model._meta.ldap_server
            response.context_data["ldap_basedn"] = self.model._meta.basedn

        return response


class LdapUserAdmin(LdapModelAdmin):
    """
    Admin class specifically for LDAP user models.

    This admin class provides user-specific functionality including
    password management and user status handling.
    """

    list_display: ClassVar[tuple[str, ...]] = ("uid", "cn", "email", "uidNumber")
    list_filter: ClassVar[tuple[str, ...]] = ("isActive", "gidNumber")
    search_fields: ClassVar[tuple[str, ...]] = ("uid", "cn", "email")
    readonly_fields: ClassVar[tuple[str, ...]] = ("uidNumber", "lastLogin")

    fieldsets: list[tuple[str, dict[str, Any]]] = (
        ("Basic Information", {"fields": ("uid", "cn", "sn", "email", "emailForward")}),
        (
            "System Information",
            {"fields": ("uidNumber", "gidNumber", "homeDirectory", "loginShell")},
        ),
        ("Status", {"fields": ("birthDate", "lastLogin", "adTimestamp")}),
        ("Security", {"fields": ("password",), "classes": ("collapse",)}),
        (
            "Additional",
            {"fields": ("photo", "groups", "description"), "classes": ("collapse",)},
        ),
    )

    def get_actions(self, request: HttpRequest) -> dict[str, Callable]:  # type: ignore[override]
        """
        Get user-specific actions.

        Args:
            request: The HTTP request

        Returns:
            dict[str, Callable]: Dictionary of user-specific action names to callable functions

        """
        actions = dict(super().get_actions(request))
        return actions

    def get_urls(self):
        """
        Add custom URLs for password management.

        Returns:
            list: List of URL patterns for this admin

        """
        urls = super().get_urls()
        custom_urls = [
            path(
                "<path:object_id>/change-password/",
                self.admin_site.admin_view(self.password_change_view),
                name="ldap_user_password_change",
            ),
        ]
        return custom_urls + urls

    def password_change_view(self, request: HttpRequest, object_id: str):
        """
        Handle password change for individual users.

        Args:
            request: The HTTP request
            object_id: The ID of the user to change password for

        Returns:
            HttpResponse: Redirect response to admin index

        """
        from django.contrib import messages

        messages.info(
            request,
            "Password change functionality is being implemented. "
            "Please use LDAP management tools for password changes.",
        )
        return redirect(reverse("admin:index"))


class LdapGroupAdmin(LdapModelAdmin):
    """
    Admin class specifically for LDAP group models.

    This admin class provides group-specific functionality including
    member management and group status handling.
    """

    list_display: tuple[str, ...] = ("cn", "gidNumber", "isActive", "member_count")
    list_filter: tuple[str, ...] = ("isActive", "gidNumber")
    search_fields: tuple[str, ...] = ("cn", "description")
    readonly_fields: tuple[str, ...] = ("gidNumber",)

    fieldsets: list[tuple[str, dict[str, Any]]] = (
        ("Basic Information", {"fields": ("cn", "description")}),
        ("System Information", {"fields": ("gidNumber",)}),
        ("Members", {"fields": ("memberUid",)}),
        ("Status", {"fields": ("isActive",)}),
    )

    def member_count(self, obj: Model) -> int:
        """
        Return the number of members in the group.

        Args:
            obj: The group model instance

        Returns:
            int: The number of members in the group

        """
        if hasattr(obj, "memberUid") and obj.memberUid:
            return len(obj.memberUid)
        return 0

    member_count.short_description = "Members"
    member_count.admin_order_field = "memberUid"

    def get_actions(self, request: HttpRequest) -> dict[str, Callable]:
        """
        Get group-specific actions.

        Args:
            request: The HTTP request

        Returns:
            dict[str, Callable]: Dictionary of group-specific action names to callable functions

        """
        actions = dict(super().get_actions(request))

        # Add member management actions
        def clear_members(
            modeladmin: ModelAdmin, request: HttpRequest, queryset: Any
        ) -> None:
            for group in queryset:
                group.memberUid = []
                group.save()

        clear_members.short_description = "Clear all members from selected groups"
        actions["clear_members"] = clear_members

        return actions


def register_ldap_model(
    ldap_model_class: type[Model], admin_class: type[ModelAdmin] | None = None
) -> type[LdapModelProxy]:
    """
    Register an ldaporm model with Django Admin.

    This function creates a proxy Django model for the ldaporm model and
    registers it with Django Admin using the specified admin class.

    Args:
        ldap_model_class: The ldaporm model class to register
        admin_class: The admin class to use (optional)

    Returns:
        type[LdapModelProxy]: The proxy model class that was registered

    Raises:
        AttributeError: If the ldaporm model doesn't have required attributes
        ValueError: If the admin class is invalid

    """
    # Create proxy Django model
    proxy_class = LdapModelProxy.create_proxy_class(ldap_model_class)

    # Use default admin class if none specified
    if admin_class is None:
        if "user" in ldap_model_class._meta.object_name.lower():
            admin_class = LdapUserAdmin
        elif "group" in ldap_model_class._meta.object_name.lower():
            admin_class = LdapGroupAdmin
        else:
            admin_class = LdapModelAdmin

    # Register with Django Admin
    admin.site.register(proxy_class, admin_class)

    return proxy_class


# Auto-register models if they have admin classes defined
def auto_register_models() -> None:
    """
    Auto-register ldaporm models with admin if they have admin classes.

    This function scans all Django apps for ldaporm models and automatically
    registers them with Django Admin if they have admin classes defined.

    Raises:
        AttributeError: If a model doesn't have required attributes
        ValueError: If an admin class is invalid

    """
    from django.apps import apps

    for app_config in apps.get_app_configs():
        if hasattr(app_config, "ldap_models"):
            for model in app_config.ldap_models:
                if hasattr(model, "Admin"):
                    register_ldap_model(model, model.Admin)
                elif hasattr(model, "admin_class"):
                    register_ldap_model(model, model.admin_class)
                else:
                    # Use default admin class based on model type
                    register_ldap_model(model)
