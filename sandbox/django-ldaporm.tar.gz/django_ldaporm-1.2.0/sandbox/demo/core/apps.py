from django.apps import AppConfig


class CoreConfig(AppConfig):
    name: str = "demo.core"
    label: str = "core"

    def ready(self):
        """Import admin module when app is ready."""
        from . import admin  # noqa: F401
