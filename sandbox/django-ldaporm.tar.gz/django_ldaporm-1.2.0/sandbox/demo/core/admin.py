from django.contrib import admin
from django.contrib.admin import ModelAdmin
from django import forms
from django.contrib import messages
from django.shortcuts import redirect
from django.urls import path, reverse
from django.http import HttpResponse
from django.template.response import TemplateResponse
from django.db import models

from .ldap.models import LDAPUser, LDAPGroup, NSRole


# Create bridge Django models for admin registration
class LDAPUserBridge(models.Model):
    """Bridge model for LDAP User admin registration."""

    uid = models.CharField(max_length=50, primary_key=True, verbose_name="Username")
    full_name = models.CharField(max_length=100, verbose_name="Full Name")
    first_name = models.CharField(max_length=100, verbose_name="First Name")
    last_name = models.CharField(max_length=100, verbose_name="Last Name")
    mail = models.CharField(max_length=254, verbose_name="Email", blank=True, null=True)
    uid_number = models.IntegerField(verbose_name="UID Number", blank=True, null=True)
    gid_number = models.IntegerField(verbose_name="GID Number", blank=True, null=True)
    home_directory = models.CharField(
        max_length=200, verbose_name="Home Directory", blank=True, null=True
    )
    login_shell = models.CharField(
        max_length=50, verbose_name="Login Shell", blank=True, null=True
    )
    employee_type = models.CharField(
        max_length=50, verbose_name="Employee Type", blank=True, null=True
    )
    employee_number = models.IntegerField(
        verbose_name="Employee Number", blank=True, null=True
    )
    room_number = models.CharField(
        max_length=50, verbose_name="Room Number", blank=True, null=True
    )
    home_phone = models.CharField(
        max_length=50, verbose_name="Home Phone", blank=True, null=True
    )
    mobile = models.CharField(
        max_length=50, verbose_name="Mobile", blank=True, null=True
    )

    class Meta:
        app_label = "core"
        verbose_name = "LDAP User"
        verbose_name_plural = "LDAP Users"
        managed = False  # Don't create database tables


class LDAPGroupBridge(models.Model):
    """Bridge model for LDAP Group admin registration."""

    cn = models.CharField(max_length=50, primary_key=True, verbose_name="Common Name")
    gid_number = models.IntegerField(verbose_name="GID Number", blank=True, null=True)
    member_uids = models.TextField(verbose_name="Member UIDs", blank=True, null=True)
    description = models.CharField(
        max_length=200, verbose_name="Description", blank=True, null=True
    )

    class Meta:
        app_label = "core"
        verbose_name = "LDAP Group"
        verbose_name_plural = "LDAP Groups"
        managed = False  # Don't create database tables


class NSRoleBridge(models.Model):
    """Bridge model for NSRole admin registration."""

    cn = models.CharField(max_length=50, primary_key=True, verbose_name="Common Name")
    description = models.CharField(
        max_length=200, verbose_name="Description", blank=True, null=True
    )

    class Meta:
        app_label = "core"
        verbose_name = "NSRole"
        verbose_name_plural = "NSRoles"
        managed = False  # Don't create database tables


class LDAPUserAdmin(ModelAdmin):
    """Admin class for LDAP User model."""

    list_display = (
        "uid",
        "full_name",
        "first_name",
        "last_name",
        "uid_number",
        "gid_number",
    )
    list_filter = ("employee_type", "gid_number")
    search_fields = ("uid", "full_name", "first_name", "last_name", "mail")
    readonly_fields = ("uid_number",)

    fieldsets = (
        ("Identity", {"fields": ("uid", "full_name", "first_name", "last_name")}),
        (
            "Contact Information",
            {"fields": ("mail", "home_phone", "mobile", "room_number")},
        ),
        (
            "System Information",
            {"fields": ("uid_number", "gid_number", "home_directory", "login_shell")},
        ),
        ("Employee Information", {"fields": ("employee_type", "employee_number")}),
    )

    def get_queryset(self, request):
        """Get queryset for LDAP User model."""
        try:
            ldap_users = LDAPUser.objects.all()
            # Convert LDAP users to bridge model instances
            bridge_users = []
            for user in ldap_users:
                bridge_user = LDAPUserBridge()
                bridge_user.uid = getattr(user, "uid", "")
                bridge_user.full_name = getattr(user, "full_name", "")
                bridge_user.first_name = getattr(user, "first_name", "")
                bridge_user.last_name = getattr(user, "last_name", "")
                bridge_user.mail = getattr(user, "mail", "")
                bridge_user.uid_number = getattr(user, "uid_number", None)
                bridge_user.gid_number = getattr(user, "gid_number", None)
                bridge_user.home_directory = getattr(user, "home_directory", "")
                bridge_user.login_shell = getattr(user, "login_shell", "")
                bridge_user.employee_type = getattr(user, "employee_type", "")
                bridge_user.employee_number = getattr(user, "employee_number", None)
                bridge_user.room_number = getattr(user, "room_number", "")
                bridge_user.home_phone = getattr(user, "home_phone", "")
                bridge_user.mobile = getattr(user, "mobile", "")
                bridge_users.append(bridge_user)
            return bridge_users
        except Exception as e:
            messages.error(request, f"Error loading LDAP users: {str(e)}")
            return []

    def save_model(self, request, obj, form, change):
        """Save the LDAP User model."""
        try:
            if change:
                # Update existing user
                ldap_user = LDAPUser.objects.get(uid=obj.uid)
                for field_name in form.cleaned_data:
                    if (
                        hasattr(ldap_user, field_name)
                        and form.cleaned_data[field_name] is not None
                    ):
                        setattr(ldap_user, field_name, form.cleaned_data[field_name])
                ldap_user.save()
            else:
                # Create new user
                user_data = form.cleaned_data
                LDAPUser.objects.create(**user_data)
            messages.success(
                request, f"User {'updated' if change else 'created'} successfully."
            )
        except Exception as e:
            messages.error(request, f"Error saving user: {str(e)}")

    def delete_model(self, request, obj):
        """Delete the LDAP User model."""
        try:
            ldap_user = LDAPUser.objects.get(uid=obj.uid)
            ldap_user.delete()
            messages.success(request, "User deleted successfully.")
        except Exception as e:
            messages.error(request, f"Error deleting user: {str(e)}")


class LDAPGroupAdmin(ModelAdmin):
    """Admin class for LDAP Group model."""

    list_display = ("cn", "gid_number", "description", "member_count")
    list_filter = ("gid_number",)
    search_fields = ("cn", "description")
    readonly_fields = ("gid_number",)

    fieldsets = (
        ("Basic Information", {"fields": ("cn", "description")}),
        ("System Information", {"fields": ("gid_number",)}),
        ("Members", {"fields": ("member_uids",)}),
    )

    def get_queryset(self, request):
        """Get queryset for LDAP Group model."""
        try:
            ldap_groups = LDAPGroup.objects.all()
            # Convert LDAP groups to bridge model instances
            bridge_groups = []
            for group in ldap_groups:
                bridge_group = LDAPGroupBridge()
                bridge_group.cn = getattr(group, "cn", "")
                bridge_group.gid_number = getattr(group, "gid_number", None)
                bridge_group.member_uids = ", ".join(
                    getattr(group, "member_uids", []) or []
                )
                bridge_group.description = getattr(group, "description", "")
                bridge_groups.append(bridge_group)
            return bridge_groups
        except Exception as e:
            messages.error(request, f"Error loading LDAP groups: {str(e)}")
            return []

    def member_count(self, obj):
        """Return the number of members in the group."""
        if obj.member_uids:
            return len(obj.member_uids.split(", "))
        return 0

    member_count.short_description = "Members"

    def save_model(self, request, obj, form, change):
        """Save the LDAP Group model."""
        try:
            if change:
                # Update existing group
                ldap_group = LDAPGroup.objects.get(cn=obj.cn)
                for field_name in form.cleaned_data:
                    if (
                        hasattr(ldap_group, field_name)
                        and form.cleaned_data[field_name] is not None
                    ):
                        if field_name == "member_uids":
                            # Convert comma-separated string back to list
                            member_list = [
                                uid.strip()
                                for uid in form.cleaned_data[field_name].split(",")
                                if uid.strip()
                            ]
                            setattr(ldap_group, field_name, member_list)
                        else:
                            setattr(
                                ldap_group, field_name, form.cleaned_data[field_name]
                            )
                ldap_group.save()
            else:
                # Create new group
                group_data = form.cleaned_data.copy()
                if "member_uids" in group_data and group_data["member_uids"]:
                    # Convert comma-separated string to list
                    group_data["member_uids"] = [
                        uid.strip()
                        for uid in group_data["member_uids"].split(",")
                        if uid.strip()
                    ]
                LDAPGroup.objects.create(**group_data)
            messages.success(
                request, f"Group {'updated' if change else 'created'} successfully."
            )
        except Exception as e:
            messages.error(request, f"Error saving group: {str(e)}")

    def delete_model(self, request, obj):
        """Delete the LDAP Group model."""
        try:
            ldap_group = LDAPGroup.objects.get(cn=obj.cn)
            ldap_group.delete()
            messages.success(request, "Group deleted successfully.")
        except Exception as e:
            messages.error(request, f"Error deleting group: {str(e)}")


class NSRoleAdmin(ModelAdmin):
    """Admin class for NSRole model."""

    list_display = ("cn", "description")
    search_fields = ("cn", "description")

    fieldsets = (("Role Information", {"fields": ("cn", "description")}),)

    def get_queryset(self, request):
        """Get queryset for NSRole model."""
        try:
            ldap_roles = NSRole.objects.all()
            # Convert LDAP roles to bridge model instances
            bridge_roles = []
            for role in ldap_roles:
                bridge_role = NSRoleBridge()
                bridge_role.cn = getattr(role, "cn", "")
                bridge_role.description = getattr(role, "description", "")
                bridge_roles.append(bridge_role)
            return bridge_roles
        except Exception as e:
            messages.error(request, f"Error loading NSRoles: {str(e)}")
            return []

    def save_model(self, request, obj, form, change):
        """Save the NSRole model."""
        try:
            if change:
                # Update existing role
                ldap_role = NSRole.objects.get(cn=obj.cn)
                for field_name in form.cleaned_data:
                    if (
                        hasattr(ldap_role, field_name)
                        and form.cleaned_data[field_name] is not None
                    ):
                        setattr(ldap_role, field_name, form.cleaned_data[field_name])
                ldap_role.save()
            else:
                # Create new role
                role_data = form.cleaned_data
                NSRole.objects.create(**role_data)
            messages.success(
                request, f"Role {'updated' if change else 'created'} successfully."
            )
        except Exception as e:
            messages.error(request, f"Error saving role: {str(e)}")

    def delete_model(self, request, obj):
        """Delete the NSRole model."""
        try:
            ldap_role = NSRole.objects.get(cn=obj.cn)
            ldap_role.delete()
            messages.success(request, "Role deleted successfully.")
        except Exception as e:
            messages.error(request, f"Error deleting role: {str(e)}")


# Register the admin classes
admin.site.register(LDAPUserBridge, LDAPUserAdmin)
admin.site.register(LDAPGroupBridge, LDAPGroupAdmin)
admin.site.register(NSRoleBridge, NSRoleAdmin)
